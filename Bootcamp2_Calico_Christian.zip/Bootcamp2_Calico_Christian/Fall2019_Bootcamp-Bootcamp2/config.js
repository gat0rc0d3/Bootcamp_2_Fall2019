//This file holds any configuration variables we may need 
//'config.js' is ignored by git to protect sensitive information, such as your database's username and password
//copy this file's contents to another file 'config.js' and store your MongoLab uri there

module.exports = {
  db: {
    uri: 'mongodb://adminBootcamp2:uTjyB!5@ds225375.mlab.com:25375/cen3031_bootcamp3_cg24681357', //place the URI of your mongo database here.
  }
};
